window.vd = require('./index')
